package com.example.emp.service;


import java.util.List;

import com.example.emp.entity.Employee;

public interface EmployeeService {
	public List<Employee> findAll();
}
